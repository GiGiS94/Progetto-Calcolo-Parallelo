#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#include <time.h>

int main(int argc, const char * argv[]) {
    int id_thread, N,fsize, numT,i=0;
    double t0,t1,t, *a,*b;
  
    printf("--------{Progetto Calcolo Parallelo e Distribuito}--------\n");
    //controllo del numero dei Threads in input
    if(argc >1) {
        numT = atoi(argv[1]);
        N = atoi(argv[2]);
    } else {
        printf("Error usage: ./exec <nThreads> <N>\n");
        exit(EXIT_FAILURE);
    }
    
    printf("il Size del Vettore è di: %d elementi \n",N);
    
    //allocazione in memoria del vettore a in base al numero degli elementi
    a=(double *)calloc(N , sizeof(double));

    //allocazione in memoria del vettore b in base al numero di thread
    b=(double *)calloc(numT , sizeof(double));

    for(i=0 ; i<=numT ; i++){
        b[i] = 1;
    }
    
    srand(time(NULL));

    for(int i=0; i<N; i++)
        {
            a[i]=((double)((rand()%10)+1)/10)+1;
            printf( "%.2f  " , a[i]);
        }
     
    t0=omp_get_wtime();
    printf("\n");

    printf("\n ---Inizio processo di Paralellizazione su %d threads--- \n",numT);
    #pragma omp parallel for shared(N,a,b) private(i) num_threads(numT)
    for (i=0; i<N; i++) 
    {
        int th_id = omp_get_thread_num();
        b[th_id] = b[th_id] * a[i];
    }
        

    //istante successivo alla parallelizzazione
    t1=omp_get_wtime();
    t=t1-t0;
    printf("\n ---------------------------------------\n");
    //Stampa risultato
    printf("\n La ricerca ha impiegato %lf secondi ",t);
    for (i=0; i<numT; i++){
        printf("\n %.2f", b[i]);
    }

    free(a);
    free(b);

    return 0;
}

